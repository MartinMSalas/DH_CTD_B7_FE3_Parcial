import React from 'react'

const Card = () => {
  return (
    <div>Hola , soy una tarjeta</div>
  )
}

export default Card