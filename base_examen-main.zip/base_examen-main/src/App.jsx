
import './App.css'
import Card from './components/Card'

function App() {


  return (
    <>
      <div>
        <h1>Carga de Estudiantes</h1>
        <form></form>
        <Card/>
      </div>
    </>
  )
}

export default App
